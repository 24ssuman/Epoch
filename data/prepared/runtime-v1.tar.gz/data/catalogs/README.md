# Stellar and other astronomical catalogs

Offline inputs and generated catalog products. See `../manifest.json` for source URLs, checksums, licenses and sizes.

`galactic.npz` is a modelled bright-star motion pack derived from the HYG 4.1 / Hipparcos catalog (`stars.json`). It covers only the supported interval, from the first instant of 15,000 BCE through 31 December 5,000 CE. `years` are Julian epochs on the TT-based Julian-date convention used by the application; `positions` are heliocentric Cartesian coordinates in parsecs, expressed in fixed ICRS axes. Motion is integrated with galpy MWPotential2014 (`ro=8.122 kpc`, `vo=229 km/s`, `zo=0.0208 kpc`, Schönrich solar motion).

This is a Galactic-potential model, not an observed historical star catalog or a validated reconstruction. It uses only the subset with finite distances, proper motions and radial velocities; other stars continue to use the explicitly approximate rectilinear propagation path. Catalog uncertainty, unresolved binaries, encounters and uncertainty in the Galactic potential limit long-term positions. Resumable batch files in `stellar-checkpoints/` use the same dates and star subset.
