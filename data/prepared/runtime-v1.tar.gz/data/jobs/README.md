# Planetary reconstruction data

Offline accepted trajectory chunks, validation reports, calibration inputs and worker checkpoints. Current application dates are 15,000 BCE–5,000 CE. Chunks store barycentric Solar System positions in AU against TDB Julian dates, seeded from JPL DE441 at 13,201 BCE and integrated backward only where DE441 has no coverage. Beyond the DE441 interval they are experimental reduced-model extrapolations, not a validated historical reconstruction; each v5 report records its interval, seed, interpolation/convergence checks and physical limitations.

The standalone worker uses REBOUND IAS15, first-order relativistic corrections, solar/Earth oblateness, simplified Earth–Moon constant-time-lag tides and 16 massive asteroids. Independent tighter integrations, off-node interpolation probes, JPL overlap residuals and local parameter sensitivity are reported separately. Numerical checks do not provide a calibrated physical uncertainty interval.

After every validated 10-year chunk, the worker writes chunk data, its validation report, and a resumable checkpoint using atomic flushed writes. The v5 history archive and latest checkpoint cover only the supported interval; a chunk crossing the 15,000 BCE boundary is retained for coverage. Resume from that in-range point after changing the lower bound. No worker data is automatically evicted.
